<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>SetTIC Acceuil</title>
    <script type="application/javascript" src="./static/js/assets/jquery/jquery-3.3.1.min.js"></script>
    <link rel="stylesheet" href="./static/css/custom/style.css">
<link rel="stylesheet" href="./static/css/assets/animate.css">
    <link rel="stylesheet" href="./static/css/custom/index.css">
    <!--    <link rel="stylesheet" href="./static/css/assets/image-slider.css">-->
</head>
<body>
<div id="wrapper">

    <header class="strong-blue">
    <img src="./static/icons/logo.png" alt="logo">

    <ul>
        <li><a href="index.php">Accueil</a></li>
        <li><a href="about.php">A propos</a>
            <!--<ul>
                <li><a href="about.php">A propos de SetTIC</a></li>
                <li><a href="accompagnement.html">Accompagnement</a></li>
            </ul>-->
        </li>
        <li><a href="deee.php">Les DEEE</a></li>
        <li><a href="accompagnement.php">Accompagnement</a></li>
        <li><a href="box.php">Nos Box de collecte</a></li>
        <li><a href="deee-management.php">Gestion de DEEE</a></li>
        <li><a href="contact.php">Contactez nous</a></li>
    </ul>
    <a href="client.php">
        <button class="green-button">Espace client</button>
    </a>
</header>
    <div id="carousel-container">
        <div id="carousel-images">
            <img src="./static/images/c1.jpg" alt="image">
            <img src="./static/images/c2.jpg" alt="image">
            <img src="./static/images/c3.jpg" alt="image">
        </div>
        <div id="carousel-layer">
            <h1 class="typed"></h1>
        </div>
    </div>

    <div id="general-presentation-block">
        <div id="upper-left-green-corner"></div>
        <div id="lower-right-green-corner"></div>
        <p>SetTIC est une éco-société évoluant dans le domaine du recyclage et de la revalorisation des Déchets
            d’Équipement Électriques et Électroniques (DEEE) au Sénégal.</p>
    </div>

    <div class="dashed-thick-green-bar"></div>

    <div id="services-container">

        <div class="service-item">
            <img src="./static/icons/box_blue.png" alt="icon">
            <div class="service-item-body">
                <h3>Box de collecte</h3>
                <p>Découvrez nos BOX de collecte ! Placées dans vos locaux, elles servent de point de collecte et de
                    support de sensibilisation pour vos collaborateurs.</p>
            </div>
        </div>

        <div class="service-item">
            <img src="./static/icons/recycle_blue.png" alt="icon">
            <div class="service-item-body">
                <h3>Gestion des DEEE</h3>
                <P>SetTIC vous propose une solution complète de gestion de vos DEEE, de la collecte au recyclage final,
                    en passant par l’inventaire et la revalorisation</P>
            </div>
        </div>

        <div class="service-item">
            <img src="./static/icons/help_blue.png" alt="icon">
            <div class="service-item-body">
                <h3>Accompagnement</h3>
                <p>Pour l’ensemble de vos besoins en gestion des déchets, SetTIC est là pour vous accompagner : audit
                    déchets, sensibilisation, implémentation</p>
            </div>
        </div>

    </div>

    <div class="dashed-thick-green-bar"></div>

    <div id="below-services-block">
        <div>
            <img src="./static/images/demantelement.jpg" alt="illustration">
        </div>
        <div>
            <h2>SetTIC</h2>
            <h3>Signification & Présentation</h3>
            <div class="thick-blue-bar"></div>
            <p>SetTIC est une combinaison des mots <strong class="green-text">Set</strong> qui signifie Propre en wolof
                et <strong class="light-blue-text">TIC</strong> pour Technologies de
                l'Information et de le communication.
                Nous fournissons une solution respectueuse de l'environnement pour gérer la fin de vie de vos
                équipements électriques et électroniques et accompagnons les entreprises et les organisations dans leur
                gestion des DEEE
                <br>
                <br>
                Nous prenons en charge les déchets d’équipements électriques et électroniques tels que les ordinateurs,
                les téléphones mobiles, les serveurs, équipements réseau & télécommunication,…
                <br>
                <br>
                Outre ces équipements, nous prenons également en charge le recyclage des déchets spéciaux tels que les
                piles et les cartouches d’impression via des BOX de collecte que nous pouvons disposer dans toutes vos
                locaux à travers le Sénégal</p>
        </div>
    </div>

    <div id="contact-us-block">
        <div>
            <h2>Vous avez peut être des questions</h2>
            <p>Vous souhaitez bénéficier des services de SetTIC ou voulez simplement obtenir des informations
                complémentaires ? N'hésitez plus et contactez nous !</p>
        </div>
        <div>
            <a href="contact.php">
                <button>Contactez nous</button>
            </a>
        </div>
    </div>

    <footer>
    <img src="./static/icons/logo.png" alt="logo">
    <span>Copyright SetTIC. All rights reserved.</span>
    <ul>
        <li><a href="https://fr-fr.facebook.com/initiative.settic/"><img src="./static/icons/facebook-logo.png"></a>
        </li>
        <li><img src="./static/icons/twitter-logo.png"></li>
        <li><img src="./static/icons/email.png"></li>
    </ul>
</footer></div>
<script src="./static/js/assets/typed.js@2.0.9"></script>
<script type="application/javascript" src="./static/js/custom/index.js"></script>
</body>
</html>