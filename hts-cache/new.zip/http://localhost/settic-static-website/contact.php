<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Contact</title>
    <link rel="stylesheet" href="./static/css/custom/style.css">
    <link rel="stylesheet" href="./static/css/custom/contact.css">
</head>
<body>

<div id="wrapper">
    <header class="strong-blue">
    <img src="./static/icons/logo.png" alt="logo">

    <ul>
        <li><a href="index.php">Accueil</a></li>
        <li><a href="about.php">A propos</a>
            <!--<ul>
                <li><a href="about.php">A propos de SetTIC</a></li>
                <li><a href="accompagnement.html">Accompagnement</a></li>
            </ul>-->
        </li>
        <li><a href="deee.php">Les DEEE</a></li>
        <li><a href="accompagnement.php">Accompagnement</a></li>
        <li><a href="box.php">Nos Box de collecte</a></li>
        <li><a href="deee-management.php">Gestion de DEEE</a></li>
        <li><a href="contact.php">Contactez nous</a></li>
    </ul>
    <a href="client.php">
        <button class="green-button">Espace client</button>
    </a>
</header>
    <div id="title-banner-bloc">
        <div>
            <h1>Contactez nous</h1>
        </div>
    </div>

    <main>
        <!--<form action="" method="post">
            <select name="clientType">
                <option value="">Vous êtes ?</option>
            </select>
            <input type="text" placeholder="Structure">
            <div>
                <input type="text" placeholder="Nom">
                <input type="text" placeholder="Prénom">
            </div>
            <input type="text" placeholder="Email">
            <div>
                <select name="" id="">
                    <option value="">Pays</option>
                </select>
                <input type="text" placeholder="Téléphone">
            </div>
            <input type="text" placeholder="Comment nous avez vous connu ?">
            <textarea name="" cols="30" rows="10" placeholder="Votre message"></textarea>
            <div>captcha</div>
            <button>Envoyer message</button>
        </form>-->
    </main>


    <footer>
    <img src="./static/icons/logo.png" alt="logo">
    <span>Copyright SetTIC. All rights reserved.</span>
    <ul>
        <li><a href="https://fr-fr.facebook.com/initiative.settic/"><img src="./static/icons/facebook-logo.png"></a>
        </li>
        <li><img src="./static/icons/twitter-logo.png"></li>
        <li><img src="./static/icons/email.png"></li>
    </ul>
</footer></div>
<script type="application/javascript" src="./static/js/assets/jquery/jquery-3.3.1.min.js"></script>
<script type="application/javascript" src="./static/js/custom/contact.js"></script>
</body>
</html>