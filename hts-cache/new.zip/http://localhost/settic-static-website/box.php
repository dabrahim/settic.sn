<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>A propos</title>
    <link rel="stylesheet" href="./static/css/custom/style.css">
    <link rel="stylesheet" href="./static/css/custom/services-box.css">
</head>
<body>
<div id="wrapper">
    <header class="strong-blue">
    <img src="./static/icons/logo.png" alt="logo">

    <ul>
        <li><a href="index.php">Accueil</a></li>
        <li><a href="about.php">A propos</a>
            <!--<ul>
                <li><a href="about.php">A propos de SetTIC</a></li>
                <li><a href="accompagnement.html">Accompagnement</a></li>
            </ul>-->
        </li>
        <li><a href="deee.php">Les DEEE</a></li>
        <li><a href="accompagnement.php">Accompagnement</a></li>
        <li><a href="box.php">Nos Box de collecte</a></li>
        <li><a href="deee-management.php">Gestion de DEEE</a></li>
        <li><a href="contact.php">Contactez nous</a></li>
    </ul>
    <a href="client.php">
        <button class="green-button">Espace client</button>
    </a>
</header>
    <main>
        <div id="title-banner-bloc">
            <div>
                <h1>Nos box de collecte</h1>
            </div>
        </div>

        <section>
            <p>SetTIC vous propose des BOX de collecte que vous pouvez placer dans vos locaux
                ou ceux de partenaires. Elles servent ainsi de support de sensibilisation et de points
                de collecte pour vos collaborateurs.
                SetTIC assurera la collecte du contenu des BOX à une fréquence préalablement
                définie.
            </p>

            <div id="boxes-block">
                <div class="box-block">
                    <img src="./static/images/electronic_waste.jpg" alt="image">
                    <div class="box-body">
                        <h1>La CartBOX</h1>
                        <p>Ne jetez plus les cartouches usagées à la poubelle, la CartBOX est là !
                            Disposée à côté des imprimantes ou à d’autres endroits stratégiques, elle sert de
                            point de collecte pour l’ensemble des cartouches produites au sein de votre
                            organisation.
                        </p>
                    </div>
                </div>

                <div class="box-block">
                    <img src="./static/images/electronic_waste.jpg" alt="image">
                    <div class="box-body">
                        <h1>La PileBOX</h1>
                        <p>Pour les piles, faites confiance à la PileBOX ! Elle rappelle la forme d’une pile et est
                            là pour collecter l’ensemble des piles produites au sein de votre organisation.
                            Vous avez développé des programmes de sensibilisation ? Demandez à vos
                            collaborateurs de venir déposer les piles usagées domestiques dans la PileBOX !
                        </p>
                    </div>
                </div>
                <div class="box-block">
                    <img src="./static/images/electronic_waste.jpg" alt="image">
                    <div class="box-body">
                        <h1>La D3BOX</h1>
                        <p>Vous produisez régulièrement des déchets électroniques de petite taille tels que les
                            téléphones mobiles, souris, petits câbles, claviers,…, utilisez la D3BOX pour les
                            recycler !
                        </p>
                    </div>
                </div>
            </div>

            <div id="bloc-0">
                <div>
                    <p>Vous souhaitez déployer</p>
                    <p>nos box de collecte dans vos bureaux ?</p>
                </div>
                <a href="contact.php">
                    <button class="blue-button">Contactez nous</button>
                </a>
            </div>
        </section>
    </main>

    <footer>
    <img src="./static/icons/logo.png" alt="logo">
    <span>Copyright SetTIC. All rights reserved.</span>
    <ul>
        <li><a href="https://fr-fr.facebook.com/initiative.settic/"><img src="./static/icons/facebook-logo.png"></a>
        </li>
        <li><img src="./static/icons/twitter-logo.png"></li>
        <li><img src="./static/icons/email.png"></li>
    </ul>
</footer></div>
<script type="application/javascript" src="./static/js/assets/jquery/jquery-3.3.1.min.js"></script>
</body>
</html>