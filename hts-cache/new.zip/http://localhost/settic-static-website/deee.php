<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>A propos</title>
    <link rel="stylesheet" href="./static/css/custom/style.css">
    <link rel="stylesheet" href="./static/css/custom/deee.css">
</head>
<body>
<div id="wrapper">
    <header class="strong-blue">
    <img src="./static/icons/logo.png" alt="logo">

    <ul>
        <li><a href="index.php">Accueil</a></li>
        <li><a href="about.php">A propos</a>
            <!--<ul>
                <li><a href="about.php">A propos de SetTIC</a></li>
                <li><a href="accompagnement.html">Accompagnement</a></li>
            </ul>-->
        </li>
        <li><a href="deee.php">Les DEEE</a></li>
        <li><a href="accompagnement.php">Accompagnement</a></li>
        <li><a href="box.php">Nos Box de collecte</a></li>
        <li><a href="deee-management.php">Gestion de DEEE</a></li>
        <li><a href="contact.php">Contactez nous</a></li>
    </ul>
    <a href="client.php">
        <button class="green-button">Espace client</button>
    </a>
</header>
    <main>
        <div id="title-banner-bloc">
            <div>
                <h1>Les DEEE</h1>
            </div>
        </div>

        <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Accusamus aliquid animi atque.</p>
        <div class="line">
            <img src="./static/images/electronic_waste.jpg" alt="garbage">
            <section>
                <div>
                    <h2>Qu’est-ce qu’un DEEE ?</h2>
                    <p>DEEE signifie Déchet d’Équipement Électrique et Électronique. Il s&#39;agit d&#39;un
                        Équipement Électrique et Électronique (EEE) ou d&#39;un de ses composants arrivé en
                        fin de vie ou ayant perdu son usage initial.
                        Les DEEE contiennent toutes sortes de composants: essentiellement des plastiques,
                        mais aussi des métaux lourds (mercure et plomb) très nocifs.
                        Ils attirent la convoitise et encouragent le recyclage informel qui impacte
                        négativement la santé publique et l’Environnement
                        Ces déchets étant issus d&#39;équipements devenus indispensables dans notre vie, il
                        devient incontournable de les gérer de façon responsable.
                        SetTIC est là pour vous aider à répondre à cet enjeu majeur: comment gérer le fin de
                        vie de vos EEE?</p>
                </div>
            </section>
        </div>

        <div class="line">
            <section>
                <div>
                    <h2>Pourquoi recycler les DEEE ?</h2>
                    <p>Les DEEE jetés à la poubelle se retrouvent dans la majorité des cas dans les
                        décharges non contrôlées où ils y sont brulés libérant ainsi des matières toxiques.
                        Ces mauvaises manipulations augmentent les émissions de gaz à effet de serre et
                        de métaux nocifs qui polluent l’air, les nappes phréatiques et contribue au
                        réchauffement climatique.
                        De plus, stocker les DEEE prend de l’espace et représente une charge pour
                        l’entreprise, ainsi qu’une pollution interne.</p>
                </div>
            </section>
            <img src="./static/images/electronic_waste.jpg" alt="garbage">
        </div>

        <div class="line">
            <img src="./static/images/electronic_waste.jpg" alt="garbage">
            <section>
                <div>
                    <h2>Recyclez vos DEEE avec SetTIC !</h2>
                    <p>Vous êtes une entreprise, une administration ou une institution publique et vous
                        détenez des équipements électriques et électroniques en fin de vie, SetTIC est là
                        pour vous accompagner
                        Les avantages de SetTIC:</p>
                    <ul>
                        <li>Une collecte directement au niveau de vos entrepôts partout au Sénégal</li>
                        <li>Un service de recyclage via les BOX que vous pouvez placer dans vos locaux et agences</li>
                        <li>Une solution de recyclage en local respectueuse de l&#39;environnement</li>
                        <li>Une transparence durant tout le processus de recyclage avec le reporting et la
                            traçabilité de vos DEEE
                        </li>
                    </ul>

                </div>
            </section>
        </div>
    </main>

    <footer>
    <img src="./static/icons/logo.png" alt="logo">
    <span>Copyright SetTIC. All rights reserved.</span>
    <ul>
        <li><a href="https://fr-fr.facebook.com/initiative.settic/"><img src="./static/icons/facebook-logo.png"></a>
        </li>
        <li><img src="./static/icons/twitter-logo.png"></li>
        <li><img src="./static/icons/email.png"></li>
    </ul>
</footer></div>
<script type="application/javascript" src="./static/js/assets/jquery/jquery-3.3.1.min.js"></script>
<script type="application/javascript" src="./static/js/custom/deee.js"></script>
</body>
</html>