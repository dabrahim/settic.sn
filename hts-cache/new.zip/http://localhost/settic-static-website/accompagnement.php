<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>A propos</title>
    <link rel="stylesheet" href="./static/css/custom/style.css">
    <link rel="stylesheet" href="./static/css/custom/accompagnement.css">
</head>
<body>
<div id="wrapper">
    <header class="strong-blue">
    <img src="./static/icons/logo.png" alt="logo">

    <ul>
        <li><a href="index.php">Accueil</a></li>
        <li><a href="about.php">A propos</a>
            <!--<ul>
                <li><a href="about.php">A propos de SetTIC</a></li>
                <li><a href="accompagnement.html">Accompagnement</a></li>
            </ul>-->
        </li>
        <li><a href="deee.php">Les DEEE</a></li>
        <li><a href="accompagnement.php">Accompagnement</a></li>
        <li><a href="box.php">Nos Box de collecte</a></li>
        <li><a href="deee-management.php">Gestion de DEEE</a></li>
        <li><a href="contact.php">Contactez nous</a></li>
    </ul>
    <a href="client.php">
        <button class="green-button">Espace client</button>
    </a>
</header>
    <main>
        <div id="title-banner-bloc">
            <div>
                <h1>Accompagnement</h1>
            </div>
        </div>

        <section>


            <div class="acc-block">
                <div class="img-container">
                    <img src="./static/icons/inventaire.png" alt="icon">
                </div>
                <h1>Inventaire</h1>
                <p>Vous disposez d’un stock d’équipements informatiques et n’avez pas de visibilité sur
                    les équipements encore fonctionnels, les équipements réparables et ceux destinés
                    au recyclage ?
                    SetTIC est là pour vous accompagner !
                    Nous déployons notre équipe sur votre site et procédons à un inventaire complet,
                    ainsi que des tests sur les équipements.
                    À l’issue de l’inventaire, nous vous fournissons un rapport d’inventaire incluant :
                    - La liste des équipements avec leurs numéros de série
                    - Le nombre et la liste des équipements fonctionnels, réparables ou destinés au
                    recyclage
                    - Des recommandations pour la gestion des différents équipements
                </p>
            </div>

            <div class="acc-block">
                <div class="img-container">
                    <img src="./static/icons/audit.png" alt="icon">
                </div>
                <h1>Audit déchets</h1>
                <p>
                    - Quelle est la nature des déchets produits dans mon entreprise ?
                    - Quelles mesures mettre en place pour prévenir la production de déchets ?
                    - Comment réduire ma production de déchets ?
                    - Est-ce que mon système actuel de gestion des déchets est optimal ?
                    Pour répondre à ces questions, SetTIC vous propose un audit déchets.

                    Qu’est-ce qu’un audit déchets ?
                    - Évaluation de votre production de déchets (volume, origine)
                    - Caractérisation de vos déchets
                    - Diagnostic du système de gestion actuel et proposition de pistes
                    d’amélioration
                    - Identification des filières de traitement
                    - Identification de pistes de réduction de déchets et des coûts de traitement
                    - Identification des besoins de sensibilisation
                    SetTIC vous apporte ainsi tous les éléments nécessaires à la mise en place d’un
                    système efficace de gestion des déchets.
                </p>

            </div>

            <div class="acc-block">
                <div class="img-container">
                    <img src="./static/icons/crowd.png" alt="icon">
                </div>
                <h1>Sensibilisation</h1>
                <p>La mise en place d’un système efficace de gestion des déchets dans une
                    organisation repose en grande partie sur l’adhésion des collaborateurs au
                    programme mis en place. D’où l’importance de sensibiliser le personnel sur
                    l’importance et les enjeux de la gestion des déchets.
                    SetTIC est là pour vous accompagner dans ce sens en vous proposant des
                    programmes de sensibilisation adapté à vos besoins internes.
                    Vous souhaitez sensibiliser votre personnel sur la gestion des déchets, contactez-
                    nous !
                </p>
            </div>
        </section>

        <!--<div class="acc-block">
            <div class="img-container">
                <img src="./static/icons/facebook-logo.png" alt="icon">
            </div>
            <h1>Inventaire</h1>
            <p>Vous disposez d’un stock d’équipements informatiques et n’avez pas de visibilité sur
                les équipements encore fonctionnels, les équipements réparables et ceux destinés
                au recyclage ?
                SetTIC est là pour vous accompagner !
                Nous déployons notre équipe sur votre site et procédons à un inventaire complet,
                ainsi que des tests sur les équipements.
                À l’issue de l’inventaire, nous vous fournissons un rapport d’inventaire incluant :
                - La liste des équipements avec leurs numéros de série
                - Le nombre et la liste des équipements fonctionnels, réparables ou destinés au
                recyclage
                - Des recommandations pour la gestion des différents équipements
            </p>
        </div>-->
    </main>

    <footer>
    <img src="./static/icons/logo.png" alt="logo">
    <span>Copyright SetTIC. All rights reserved.</span>
    <ul>
        <li><a href="https://fr-fr.facebook.com/initiative.settic/"><img src="./static/icons/facebook-logo.png"></a>
        </li>
        <li><img src="./static/icons/twitter-logo.png"></li>
        <li><img src="./static/icons/email.png"></li>
    </ul>
</footer></div>
<script type="application/javascript" src="./static/js/assets/jquery/jquery-3.3.1.min.js"></script>
</body>
</html>