<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>A propos</title>
    <link rel="stylesheet" href="./static/css/custom/style.css">
    <link rel="stylesheet" href="./static/css/custom/about.css">
</head>
<body>
<div id="wrapper">

    <header class="strong-blue">
    <img src="./static/icons/logo.png" alt="logo">

    <ul>
        <li><a href="index.php">Accueil</a></li>
        <li><a href="about.php">A propos</a>
            <!--<ul>
                <li><a href="about.php">A propos de SetTIC</a></li>
                <li><a href="accompagnement.html">Accompagnement</a></li>
            </ul>-->
        </li>
        <li><a href="deee.php">Les DEEE</a></li>
        <li><a href="accompagnement.php">Accompagnement</a></li>
        <li><a href="box.php">Nos Box de collecte</a></li>
        <li><a href="deee-management.php">Gestion de DEEE</a></li>
        <li><a href="contact.php">Contactez nous</a></li>
    </ul>
    <a href="client.php">
        <button class="green-button">Espace client</button>
    </a>
</header>
    <main>
        <div id="title-banner-bloc">
            <div>
                <h1>A propos de SetTIC</h1>
            </div>
        </div>

        <div id="about-bloc-2">
            <div id="card-bloc">
                <div class="card">
                    <div></div>
                    <h1>Lorem Ipsum Title</h1>
                    <div class="blue-bar"></div>
                    <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Accusantium alias aperiam asperiores at culpa.</p>
                </div>
                <div class="card">
                    <div></div>
                    <h1>Lorem Ipsum Title</h1>
                    <div class="blue-bar"></div>
                    <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Accusantium alias aperiam asperiores at culpa.</p>
                </div>
                <div class="card">
                    <div></div>
                    <h1>Lorem Ipsum Title</h1>
                    <div class="blue-bar"></div>
                    <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Accusantium alias aperiam asperiores at culpa.</p>
                </div>
            </div>
            <div>
                <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Ab ad alias, aperiam dolore dolores ea eius enim Lorem ipsum dolor sit amet, consectetur adipisicing elit. Ab ad alias, aperiam dolore dolores et</p>
            </div>
        </div>

        <div id="about-bloc-3">
            <h1>consectetur adipisicing elit</h1>
            <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Amet aut corporis dicta distinctio eligendi explicabo, fuga iste libero molestiae molestias omnis placeat possimus reiciendis sit tempore unde veniam voluptate. Dolore.</p>
            <!--<p>SetTIC est une combinaison des mots Set qui signifie Propre en wolof
                et TIC pour Technologies de l&#39;Information et de le communication.
                Nous fournissons une solution respectueuse de l&#39;environnement pour gérer la fin de vie de
                vos équipements électriques et électroniques et accompagnons les entreprises et les
                organisations dans leur gestion des DEEE</p>-->
            <div id="container">
                <div id="card-container">
                    <div class="card-2">
                        <div></div>
                        <div>
                            <strong>Lorem ipsum title</strong>
                            <span>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Aperiam consequuntur, cumque debitis dicta dolorem enim esse eveniet impedit in incidunt inventore iusto, maxime mollitia neque non, placeat vitae. Deserunt, nesciunt?</span>
                        </div>
                    </div>
                    <div class="card-2">
                        <div></div>
                        <div>
                            <strong>Lorem ipsum title</strong>
                            <span>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Adipisci asperiores, beatae commodi cumque deleniti dolorum facere, laborum magnam numquam possimus quaerat quasi qui ratione recusandae rerum suscipit tempore veniam! Quos.</span>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div id="white-area"></div>
    </main>

    <footer>
    <img src="./static/icons/logo.png" alt="logo">
    <span>Copyright SetTIC. All rights reserved.</span>
    <ul>
        <li><a href="https://fr-fr.facebook.com/initiative.settic/"><img src="./static/icons/facebook-logo.png"></a>
        </li>
        <li><img src="./static/icons/twitter-logo.png"></li>
        <li><img src="./static/icons/email.png"></li>
    </ul>
</footer>
</div>
<script type="application/javascript" src="./static/js/assets/jquery/jquery-3.3.1.min.js"></script>
<script type="application/javascript" src="./static/js/custom/about.js"></script>
</body>
</html>
